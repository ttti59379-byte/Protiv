# GeoKey Touch — Android Bluetooth keyboard-to-touch mapper

**Experimental prototype. Not tested on a real Xiaomi Redmi Note 11 Pro.**

This independent app uses an Android AccessibilityService to capture selected hardware keyboard keys only when the chosen Geometry Dash package has an active window. A selected key is mapped to a configured screen coordinate, in tap or long-hold mode. No Shizuku, root, internet, or full-screen persistent overlay is required.

## Installation / setup (Russian)

1. Установи собранный `app-debug.apk`.
2. Отключи KeySync в **Настройки → Специальные возможности**, чтобы службы не конкурировали за клавиши.
3. Запусти **GeoKey Touch**, нажми **Включить специальные возможности** и активируй **GeoKey Touch — клавиатура для игр**.
4. Выбери версию Geometry Dash и назначь W, стрелку ↑, пробел и любые другие клавиши.
5. Для каждой клавиши выбери координаты (в процентах дисплея) и **Hold** для корабля и волны.
6. Запусти игру кнопкой в приложении. Касания пальцами должны продолжать работать, потому что постоянно активного наложения нет.

If Android says accessibility settings are restricted, open Settings → Apps → GeoKey Touch → ⋮ → Allow restricted settings (when available), then enable the service.

## Known limitations

- `dispatchGesture` can cancel touches already in progress when the hardware key is pressed (Android system behavior). It is not zero-latency.
- Android's accessibility gesture continuation may behave differently across Xiaomi firmware releases. Holding has not been device-tested.
- Only one simultaneous mapped touch is supported. For Geometry Dash jumping this is typically sufficient.
- Does not impersonate physical touchscreen drivers; games may restrict accessibility-injected gestures.
- Key filtering works only if the selected app is observed as foreground through window state events. Some full-screen games might fail to expose those events; then mappings deliberately remain inactive.
- Android grants the accessibility service broad privileges. This app doesn't access screen content, log keypresses or use the network, but only enable it if you trust the source.

## Build

Open the folder in Android Studio with JDK 17 and Android SDK platform 35, then Build → Build APK(s). Or use GitHub Actions workflow in this repository on the `geometrydash-keyboard-mapper` branch; artifacts contain a debug-signed installable APK.

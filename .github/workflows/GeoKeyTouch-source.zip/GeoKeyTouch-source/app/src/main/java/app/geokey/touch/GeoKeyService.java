package app.geokey.touch;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Hardware keyboard events -> Accessibility gestures, without any overlay.
 * GestureDescription continued stroke is used for a physical hold until key-up.
 * The service listens for window changes solely to restrict keys to the selected game.
 */
public class GeoKeyService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private String foregroundPackage = "";
    private GestureDescription.StrokeDescription pendingStroke;
    private int heldKey = -1;
    private boolean held = false;
    private boolean downInFlight = false;
    private final int[] defaults = {KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_S};

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        if (event.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            CharSequence p = event.getPackageName();
            if (p!=null) {
                String next = p.toString();
                // The selected game must be the foreground app. Never capture globally.
                if (!next.equals(foregroundPackage)) {
                    foregroundPackage=next;
                    if (heldKey!=-1 && !isInGame()) stopHold();
                }
            }
        }
    }
    @Override public void onInterrupt() { stopHold(); }
    @Override public void onDestroy() { stopHold(); super.onDestroy(); }
    private boolean isInGame() {
        return prefs!=null && prefs.getBoolean("master",true) &&
            foregroundPackage.equals(prefs.getString("package", MainActivity.PACKAGES[0]));
    }
    @Override protected boolean onKeyEvent(KeyEvent event) {
        if (!isInGame()) return false;
        final int key=event.getKeyCode();
        int slot=-1;
        for(int i=0;i<6;i++) {
            if (prefs.getBoolean("enabled_"+i,i==0) && prefs.getInt("key_"+i,defaults[i])==key) {slot=i;break;}
        }
        if(slot<0) return false;
        if(event.getAction()==KeyEvent.ACTION_DOWN) {
            if(event.getRepeatCount()==0) {
                if(prefs.getBoolean("hold_"+slot,true)) beginHold(key,slot);
                else tap(slot);
            }
        } else if(event.getAction()==KeyEvent.ACTION_UP) {
            if(key==heldKey) stopHold();
        }
        return true; // Consume both events, preserving a matching event stream.
    }
    private Path pointPath(int slot) {
        WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        Display d=wm.getDefaultDisplay();
        Point s=new Point(); d.getRealSize(s);
        int x=prefs.getInt("x_"+slot,75); int y=prefs.getInt("y_"+slot,50);
        Path p=new Path();p.moveTo(Math.max(1,s.x-1)*Math.max(1,Math.min(99,x))/100f,
                         Math.max(1,s.y-1)*Math.max(1,Math.min(99,y))/100f);return p;
    }
    private void tap(int slot) {
        if (heldKey!=-1) return;
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(pointPath(slot),0,35);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture,null,handler);
    }
    private void beginHold(int key,int slot) {
        if (heldKey!=-1) return;  // GestureDescription can't safely inject overlapping independent holds.
        heldKey=key;held=true;downInFlight=true;
        GestureDescription.StrokeDescription down=new GestureDescription.StrokeDescription(pointPath(slot),0,16,true);
        GestureDescription g=new GestureDescription.Builder().addStroke(down).build();
        boolean accepted=dispatchGesture(g,new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription description) {
                downInFlight=false;pendingStroke=down;
                if(!held) releaseHold();
            }
            @Override public void onCancelled(GestureDescription description) {
                clearHold();
            }
        },handler);
        if(!accepted) clearHold();
    }
    private void stopHold() {
        if(heldKey==-1) return;
        held=false;
        if(!downInFlight) releaseHold();
    }
    private void releaseHold() {
        if(pendingStroke==null) { clearHold();return; }
        GestureDescription.StrokeDescription ending;
        try {
            // Maintain the same location, then send ACTION_UP through a continued stroke.
            ending=pendingStroke.continueStroke(pendingStroke.getPath(),0,16,false);
        } catch(Exception ex) { clearHold();return; }
        clearHold();
        dispatchGesture(new GestureDescription.Builder().addStroke(ending).build(),null,handler);
    }
    private void clearHold() {
        heldKey=-1;held=false;downInFlight=false;pendingStroke=null;
    }
}

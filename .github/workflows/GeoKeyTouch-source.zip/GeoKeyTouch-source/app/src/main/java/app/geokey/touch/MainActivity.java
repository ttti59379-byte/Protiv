package app.geokey.touch;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    static final String PREFS = "geokey_maps";
    static final String[] PACKAGES = {
        "com.robtopx.geometryjump", "com.robtopx.geometryjumplite", "com.robtopx.geometrydashworld",
        "com.robtopx.geometrydashmeltdown", "com.robtopx.geometrydashsubzero"
    };
    static final String[] GAME_NAMES = {"Geometry Dash", "Geometry Dash Lite", "Geometry Dash World", "Geometry Dash Meltdown", "Geometry Dash SubZero"};
    private SharedPreferences prefs;
    private LinearLayout page;
    private int captureSlot = -1;
    private Button captureButton;
    private int blue = Color.rgb(35, 92, 208);
    private int lightBg = Color.rgb(244, 247, 251);
    private final int[] defaultKeys = {KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_S};

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
    }
    private int dp(int n) { return (int)(getResources().getDisplayMetrics().density * n + 0.5f); }
    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setPadding(0, dp(5), 0, dp(7)); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private void add(LinearLayout parent, View child) { parent.addView(child); }
    private String keyLabel(int key) {
        String label = KeyEvent.keyCodeToString(key).replace("KEYCODE_", "");
        if (key == KeyEvent.KEYCODE_DPAD_UP) return "↑";
        if (key == KeyEvent.KEYCODE_DPAD_DOWN) return "↓";
        if (key == KeyEvent.KEYCODE_DPAD_LEFT) return "←";
        if (key == KeyEvent.KEYCODE_DPAD_RIGHT) return "→";
        if (key == KeyEvent.KEYCODE_SPACE) return "Пробел";
        if (key == KeyEvent.KEYCODE_ENTER) return "Enter";
        return label;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        page = column(); page.setPadding(dp(18),dp(18),dp(18),dp(24)); page.setBackgroundColor(lightBg);
        scroll.addView(page); setContentView(scroll);
        add(page, text("GeoKey Touch", 27, blue));
        add(page, text("Клавиатура → касания в Geometry Dash", 16, Color.DKGRAY));
        add(page, text("Без Shizuku, без полноэкранного наложения. Настройки применяются сразу. При зажатии клавиши удерживается касание, при отпускании — прекращается.", 14, Color.DKGRAY));
        Button accessibility = new Button(this); accessibility.setText("1. ВКЛЮЧИТЬ СПЕЦИАЛЬНЫЕ ВОЗМОЖНОСТИ");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        add(page, accessibility);
        add(page, text("Найди «GeoKey Touch — клавиатура для игр» и разреши службу. Перед этим отключи службу KeySync, чтобы они не перехватывали клавиши друг у друга.", 13, Color.DKGRAY));
        add(page, text("2. Выбери игру", 19, Color.BLACK));
        Spinner chooseGame = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, GAME_NAMES);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chooseGame.setAdapter(adapter);
        String selectedPkg = prefs.getString("package", PACKAGES[0]);
        for (int i=0;i<PACKAGES.length;i++) if (PACKAGES[i].equals(selectedPkg)) chooseGame.setSelection(i);
        chooseGame.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                prefs.edit().putString("package",PACKAGES[position]).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        add(page, chooseGame);
        CheckBox master = new CheckBox(this); master.setText("Включить управление для выбранной игры");
        master.setChecked(prefs.getBoolean("master", true));
        master.setOnCheckedChangeListener((button, checked)->prefs.edit().putBoolean("master", checked).apply());
        add(page, master);
        add(page, text("3. Назначь клавиши и точки касания", 19, Color.BLACK));
        add(page, text("В Geometry Dash касаться можно любой свободной области игрового поля. Начни с X=75%, Y=50%. В меню продолжай пользоваться сенсором.", 13, Color.DKGRAY));
        for (int i=0;i<6;i++) addSlot(i);
        Button open = new Button(this); open.setText("4. ЗАПУСТИТЬ GEOMETRY DASH");
        open.setOnClickListener(v -> {
            String pkg = prefs.getString("package", PACKAGES[0]);
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch == null) Toast.makeText(this,"Выбранная игра не установлена или не найдена",Toast.LENGTH_LONG).show();
            else startActivity(launch);
        }); add(page, open);
        add(page, text("Важно: Android может отменить уже выполняющееся касание пальцем при отправке программного жеста. Работа удержания и задержка зависят от прошивки Xiaomi. Приложение не проверено на реальном Redmi Note 11 Pro.", 12, Color.GRAY));
    }
    private void addSlot(final int index) {
        LinearLayout card = column(); card.setPadding(dp(12), dp(10), dp(12),dp(10));
        card.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.bottomMargin=dp(12);page.addView(card,cp);
        CheckBox enabled = new CheckBox(this); enabled.setText("Клавиша " + (index+1));
        enabled.setChecked(prefs.getBoolean("enabled_" + index, index==0));
        enabled.setOnCheckedChangeListener((b,v)->prefs.edit().putBoolean("enabled_"+index,v).apply());
        add(card,enabled);
        int key = prefs.getInt("key_"+index,defaultKeys[index]);
        Button bind = new Button(this); bind.setAllCaps(false);bind.setText("Назначить: " + keyLabel(key));
        bind.setOnClickListener(v -> {
            if (captureButton!=null && captureButton!=bind) captureButton.setText("Назначение отменено");
            captureSlot=index;captureButton=bind;bind.setText("Нажми нужную клавишу…");
        });
        add(card,bind);
        CheckBox hold = new CheckBox(this); hold.setText("Удержание (Hold)");
        hold.setChecked(prefs.getBoolean("hold_"+index,true));
        hold.setOnCheckedChangeListener((b,v)->prefs.edit().putBoolean("hold_"+index,v).apply());
        add(card,hold);
        slider(card,index,"X",75);
        slider(card,index,"Y",50);
    }
    private void slider(LinearLayout card, final int index, final String axis, int def) {
        String pref = axis.toLowerCase() + "_" + index;
        int start = prefs.getInt(pref, def);
        TextView label = text(axis + " = " + start + "%",14,Color.DKGRAY); add(card,label);
        SeekBar bar = new SeekBar(this); bar.setMax(100);bar.setProgress(start);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar,int value, boolean fromUser) {
                label.setText(axis + " = " + value + "%");
                if (fromUser) prefs.edit().putInt(pref,Math.max(1, Math.min(99,value))).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar b) {}
            @Override public void onStopTrackingTouch(SeekBar b) {}
        }); add(card,bar);
    }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (captureSlot >= 0 && event.getRepeatCount()==0) {
            if (keyCode != KeyEvent.KEYCODE_BACK && keyCode != KeyEvent.KEYCODE_HOME) {
                prefs.edit().putInt("key_"+captureSlot,keyCode).apply();
                captureButton.setText("Назначить: " + keyLabel(keyCode));
                captureSlot=-1;captureButton=null;
                return true;
            }
            captureSlot=-1;captureButton=null;
        }
        return super.onKeyDown(keyCode,event);
    }
    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (prefs!=null) {
            for (int i=0;i<6;i++) if (prefs.getInt("key_"+i, defaultKeys[i])==keyCode) return true;
        }
        return super.onKeyUp(keyCode,event);
    }
}
